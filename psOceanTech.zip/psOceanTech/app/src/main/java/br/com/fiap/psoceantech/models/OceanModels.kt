package br.com.fiap.psoceantech.models

data class Ocean(
    val animais: String,
    val phAgua: String,
    val residuos: String,
    val id : Long
)